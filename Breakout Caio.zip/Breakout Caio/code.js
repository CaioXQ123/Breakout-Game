var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["7d95ca21-9758-423f-9b05-0965d4ed595c"],"propsByKey":{"7d95ca21-9758-423f-9b05-0965d4ed595c":{"name":"start","sourceUrl":null,"frameSize":{"x":108,"y":48},"frameCount":1,"looping":true,"frameDelay":12,"version":"8esaqZWjbCdpmphp5aLsXaBwLqtmwTMz","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":108,"y":48},"rootRelativePath":"assets/7d95ca21-9758-423f-9b05-0965d4ed595c.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var player = createSprite(200,380,120,10);
player.shapeColor="pink";

var ball= createSprite(200,300,20,20);
ball.shapeColor="pink";

createEdgeSprites();

var blocos=createGroup();

criarblocos(66,"red");
criarblocos(66+29,"orange");
criarblocos(66+58,"yellow");
criarblocos(66+87,"green");
var start=createSprite(200,200);
start.setAnimation("start");
start.scale=1.5;
function draw() {
  background("black");
  score = 0;
  textSize(15);
  stroke("white");
  text("Pontuação:" + score,300,20);
  drawSprites();
  player.x=World.mouseX;
  ball.bounceOff(leftEdge);
  ball.bounceOff(rightEdge);
  ball.bounceOff(topEdge);
  ball.bounceOff(player);
  ball.bounceOff(blocos, destruirbloco);
  if (keyDown("space")){
    ball.velocityX=-7;
    ball.velocityY=5;
    start.destroy();
  }
  if(ball.isTouching(bottomEdge)){
    textSize(40);
    stroke("white");
    text("Você Perdeu!!!", 75, 200);
  }
  if(score===24){
    textSize(40);
    stroke("white");
    text("Você Ganhou!!!",75,200);
  }
}

function criarblocos(y,color){
for (var i=0; i<6;i++){
  var bloco=createSprite(64+54*i, y,50,25);
  bloco.shapeColor=color;
  blocos.add(bloco);
  
  }
}
function destruirbloco (ball, bloco){
  //playSound("assets/category_hits/puzzle_game_button_04.mp3");
  bloco.remove ();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
